export const environment = {
  production: false,
  firebase: {
    apiKey: "DATA EXPUNGED",
    authDomain: "DATA EXPUNGED",
    databaseURL: "DATA EXPUNGED",
    projectId: "DATA EXPUNGED",
    storageBucket: "DATA EXPUNGED",
    messagingSenderId: "DATA EXPUNGED",
    appId: "DATA EXPUNGED"
  }
};