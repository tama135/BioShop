import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-previous-training',
  templateUrl: './previous-training.component.html',
  styleUrls: ['./previous-training.component.css']
})
export class PreviousTrainingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
