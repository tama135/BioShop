export interface AccountData {
  fullname: string;
  username: string;
  email: string;
 // password: string;
  city: string;
  address: string;
  phoneNumber: string;
  favoriteCategory: string;

}
